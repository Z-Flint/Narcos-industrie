<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style4.css"/>
    <title>Account page</title>
</head>
<body>
<header>
      <div id="menu-bar">
			<div id="menu" onclick="onClickMenu()">
				<div id="bar1" class="bar"></div>
				<div id="bar2" class="bar"></div>
				<div id="bar3" class="bar"></div>
      </div>
        <ul class="nav" id="nav">
          <li><a href="./index.php">Home</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="./narcos2.php">Nouveauté</a></li>
          <li><a href="#">Contact</a></li>
        </ul>
      </div>
        </div>
        </div>
        <div class="recherche">
        <input type="search" name="Search" placeholder="Search">
      </div>
  </header>
  <div class="menu-bg" id="menu-bg"></div>
    <script src="./JS/script.js"></script>
    
</body>
</html>