<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--<link rel="stylesheet" href="./css/style.css" />-->
    <link rel="stylesheet" type="text/css" href="./css/style.css?refresh=<?php echo rand(2, 200) ?>" />
    <title>Page principale</title>
</head>
<body>
<header></header>
        <div class="vod">
            <video controls>
            <source src="./image/mavideo.mp4" type="video/mp4">
            </video>
        </div>
        <div class="bouton">
        <div class="hbouton">
        <a href="./narcos2.php">Accedés au site officiel</a>
        </div>
        </div>
</div>
</body>
</html>